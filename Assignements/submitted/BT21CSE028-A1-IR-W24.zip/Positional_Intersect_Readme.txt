
Positional Intersect Algorithm
==============================

Overview
--------
The Positional Intersect algorithm is used in information retrieval systems to find documents where two terms appear within a certain proximity of each other, defined by a maximum allowed distance k in terms of word positions. This algorithm is particularly useful for phrase queries or proximity searches in search engines.

Features
--------
- Efficiently processes two posting lists (p1 and p2) to identify documents and positions where the proximity condition is satisfied.
- Handles cases with overlapping positions and multiple matches within the same document.
- Outputs a list of tuples containing the document ID and the positions of the terms that satisfy the proximity condition.

Algorithm
---------
The algorithm compares the document IDs from two posting lists (p1 and p2). If the document IDs match, it then compares the positions of the terms within the documents. The positions are checked to see if they are within the specified proximity (k). If they are, the positions are recorded in the result list.

Input
-----
- Posting List 1 (p1): A list of documents, each containing a document ID and a list of positions where the term appears.
- Posting List 2 (p2): A list of documents, each containing a document ID and a list of positions where another term appears.
- Proximity (k): The maximum allowed distance between the positions of the two terms.

Output
------
A list of tuples, each containing:
- The document ID (docID)
- The position of the term from p1 (pos1)
- The position of the term from p2 (pos2)

Example
-------
### Input:
- Posting List 1 (p1):
  - DocID 1: Positions [2, 5, 10]
  - DocID 2: Positions [1, 4, 9]

- Posting List 2 (p2):
  - DocID 1: Positions [3, 8, 12]
  - DocID 2: Positions [2, 5, 10]

- Proximity (k): 2

### Output:
- For DocID 1:
  - Pos1 = 2, Pos2 = 3
- For DocID 2:
  - Pos1 = 1, Pos2 = 2
  - Pos1 = 4, Pos2 = 5
  - Pos1 = 9, Pos2 = 10

Installation
------------
1. Clone the repository or download the source code.
2. Ensure you have a C++ compiler installed (e.g., g++).
3. Compile the code using the following command:

   ```bash
   g++ -o positional_intersect positional_intersect.cpp
   ```

4. Run the executable:

   ```bash
   ./positional_intersect
   ```

Usage
-----
Modify the main function in the positional_intersect.cpp file to use your own posting lists and proximity value (k). The results will be printed to the console.

Test Cases
----------
Here are some suggested test cases to validate the implementation:

1. Simple Matching:
   - p1 = [{1, [2, 5, 10]}, {2, [1, 4, 9]}]
   - p2 = [{1, [3, 8, 12]}, {2, [2, 5, 10]}]
   - k = 2
   - Expected Output: Matching positions for DocIDs 1 and 2.

2. No Matching Documents:
   - p1 = [{3, [1, 4, 7]}, {4, [3, 8]}]
   - p2 = [{1, [2, 6]}, {2, [1, 5, 9]}]
   - k = 2
   - Expected Output: No matching positions.

3. Multiple Matches in the Same Document:
   - p1 = [{1, [1, 10, 20]}, {2, [5, 15, 25]}]
   - p2 = [{1, [3, 12, 22]}, {2, [7, 17, 27]}]
   - k = 5
   - Expected Output: Multiple matches within the same document.

4. Edge Case with Overlapping Positions:
   - p1 = [{1, [1, 2, 3, 10]}]
   - p2 = [{1, [2, 3, 4, 11]}]
   - k = 1
   - Expected Output: Overlapping positions within the proximity.

5. No Positions within the Range k:
   - p1 = [{1, [1, 10, 20]}, {2, [5, 15, 25]}]
   - p2 = [{1, [3, 13, 23]}, {2, [7, 17, 27]}]
   - k = 1
   - Expected Output: No matching positions within the specified proximity.

Acknowledgments
---------------
This implementation is based on the positional intersection algorithm commonly used in information retrieval systems, particularly for phrase queries or proximity searches.
